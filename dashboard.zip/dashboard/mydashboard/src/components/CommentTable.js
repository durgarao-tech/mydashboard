import { useEffect, useState } from "react";

export default function CommentTable() {
  const [comments, setComments] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/comments")
      .then(res => res.json())
      .then(data => setComments(data));
  }, []);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value.toLowerCase());
    setPage(1); 
  };

  
  const filteredComments = comments.filter(comment =>
    comment.name.toLowerCase().includes(searchTerm) ||
    comment.email.toLowerCase().includes(searchTerm) ||
    comment.body.toLowerCase().includes(searchTerm)
  );

  const totalPages = Math.ceil(filteredComments.length / pageSize);
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const visibleComments = filteredComments.slice(startIndex, endIndex);

  const handlePageChange = (direction) => {
    if (direction === "prev" && page > 1) setPage(page - 1);
    else if (direction === "next" && page < totalPages) setPage(page + 1);
  };

  const handlePageSizeChange = (e) => {
    setPageSize(Number(e.target.value));
    setPage(1);
  };

  return (
    <div>
      <div style={{ marginBottom: "10px" }}>
        <input
          type="text"
          placeholder="Search by name, email or body..."
          value={searchTerm}
          onChange={handleSearch}
          style={{ padding: "5px", width: "300px" }}
        />
      </div>

      <div style={{ marginBottom: "10px" }}>
        <label>Page Size: </label>
        <select value={pageSize} onChange={handlePageSizeChange}>
          <option value={10}>10</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
        </select>
      </div>

      <p>Total Filtered Comments: {filteredComments.length}</p>

      <table border="1" width="100%">
        <thead>
          <tr>
            <th>Post ID</th>
            <th>Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {visibleComments.map(comment => (
            <tr key={comment.id}>
              <td>{comment.postId}</td>
              <td>{comment.name}</td>
              <td>{comment.email}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginTop: "10px" }}>
        <button onClick={() => handlePageChange("prev")} disabled={page === 1}>
          Previous
        </button>
        <span style={{ margin: "0 10px" }}>
          Page {page} of {totalPages}
        </span>
        <button onClick={() => handlePageChange("next")} disabled={page === totalPages}>
          Next
        </button>
      </div>
    </div>
  );
}
