import { useNavigate } from "react-router-dom";
import CommentTable from "../components/CommentTable";

export default function Dashboard() {
  const navigate = useNavigate();

  return (
    <div style={{ padding: "20px" }}>
      <h1>Comments Dashboard</h1>

      <button
        onClick={() => navigate("/profile")}
        style={{
          marginBottom: "20px",
          padding: "8px 12px",
          backgroundColor: "#4caf50",
          color: "#fff",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer"
        }}
      >
        Go to Profile
      </button>

      <CommentTable />
    </div>
  );
}
