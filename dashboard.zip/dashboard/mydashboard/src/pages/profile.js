import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Profile() {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => res.json())
      .then((data) => setUser(data[0]));
  }, []);

  return (
    <div style={{ padding: "20px" }}>
      <h1>User Profile</h1>

      {user ? (
        <div style={{ marginBottom: "20px" }}>
          <p><strong>Name:</strong> {user.name}</p>
          <p><strong>Email:</strong> {user.email}</p>
          <p><strong>Phone:</strong> {user.phone}</p>
        </div>
      ) : (
        <p>Loading profile...</p>
      )}

      <button
        onClick={() => navigate("/")}
        style={{
          padding: "8px 12px",
          backgroundColor: "#2196f3",
          color: "#fff",
          border: "none",
          borderRadius: "4px",
          cursor: "pointer"
        }}
      >
        Back to Dashboard
      </button>
    </div>
  );
}
