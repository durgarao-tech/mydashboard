const USERS_API_URL = "https://jsonplaceholder.typicode.com/users";
const COMMENTS_API_URL = "https://jsonplaceholder.typicode.com/comments";

// Get all users
export async function fetchUsers() {
  try {
    const response = await fetch(USERS_API_URL);
    if (!response.ok) throw new Error("Failed to fetch users");
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching users:", error);
    return [];
  }
}

// Get all comments
export async function fetchComments() {
  try {
    const response = await fetch(COMMENTS_API_URL);
    if (!response.ok) throw new Error("Failed to fetch comments");
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Error fetching comments:", error);
    return [];
  }
}
