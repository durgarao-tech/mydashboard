const STORAGE_KEY = "dashboardFilters";

// Save dashboard state to localStorage
export function saveDashboardState({ searchTerm, sortConfig, page, pageSize }) {
  const state = {
    searchTerm,
    sortConfig,
    page,
    pageSize,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

// Load dashboard state from localStorage
export function loadDashboardState() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (error) {
      console.error("Error parsing dashboard state:", error);
    }
  }
  return {
    searchTerm: "",
    sortConfig: { key: null, direction: null },
    page: 1,
    pageSize: 10,
  };
}
